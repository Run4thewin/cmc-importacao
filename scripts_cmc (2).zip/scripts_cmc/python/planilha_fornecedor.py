import pandas as pd
from db import createFabricante

def get_df():
    # Replace 'your_file.xlsx' with the path to your file
    file_path = 'FORNECEDORES.xlsx'

    # Read the Excel file into a DataFrame
    df = pd.read_excel(file_path, )

    listToAdd = []
    # Iterate over each row using itertuples()
    for row in df.itertuples(index=True, name='Pandas'):
        if(row.FRABRICANTE not in listToAdd):
            listToAdd.append(row)
            
    return listToAdd