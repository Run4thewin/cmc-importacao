from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
import time
import re
import pandas as pd
import pandas as pd
from datetime import datetime
import time
import argparse
from selenium.webdriver.common.action_chains import ActionChains
from db import createOrcamento, Orcamento, getListImportacao, getListOrcamento


# Create the parser
#parser = argparse.ArgumentParser(description="A script that accepts a password argument.")
# Add the password argument
#parser.add_argument("--login", type=str, required=True, help="The password for the program")
# Add the password argument
#parser.add_argument("--password", type=str, required=True, help="The password for the program")
# Parse the command-line arguments
#args = parser.parse_args()

# Access the password
#login = args.login
# Access the password
#password = args.password

#CrisCaio#1DeusCmC
#vendas@cmcimportacao.com.br
login = "vendas@cmcimportacao.com.br"#input("Digite o login:")
password = "CrisCaio#1DeusCmC"#input("Digite a senha:") 


print('Incio:', datetime.now().strftime("%Y-%m-%d %H:%M:%S"))


service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
actions = ActionChains(driver)

driver.maximize_window()
driver.execute_script("document.body.style.zoom='150%'")

driver.get("https://login.nimbi.com.br/")
#PREENCHE EMAIL
emailField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtUsernameField")
driver.execute_script("arguments[0].style.border='2px solid red'", emailField)
emailField.send_keys(login)
#CLICA BOTAO LOGIN EMAIL
sendButton = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtFirstStep")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButton)
sendButton.click()
time.sleep(1.5)    # Pause 5.5 seconds
#ENTRANDO COM SENHA
passwordField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtinpPassword")
driver.execute_script("arguments[0].style.border='2px solid red'", passwordField)
passwordField.send_keys(password)
#CLICA BOTAO LOGIN SENHA
sendButtonPass = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtSignin")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButtonPass)
sendButtonPass.click()
time.sleep(10.5)    # Pause 5.5 seconds
#CHECK IF ROBOTS STOPPED ME
captcha = driver.find_elements(by=By.ID, value="wtLayout_Normal_2Col_wtLoginElements_wtLoginWB_V2_wt16_wtCaptchaValidation")
if(len(captcha) > 0):
    print('Travado captcha')
    time.sleep(60)

listaPedidosColetados = []

rfqsBanco = getListImportacao()
rfqsOrcamento = getListOrcamento()
# Create DataFrame with custom column names
df = pd.DataFrame(rfqsBanco, columns=['rfq'])
# Create DataFrame with custom column names
dfOrcamento = pd.DataFrame(rfqsOrcamento, columns=['rfq'])

for pedido in [item for item in df['rfq'].tolist() if item not in dfOrcamento['rfq'].tolist()]:
    print("Bucando", pedido)
    # Send the request to the Sheets API
    comecoProcesso = time.time()
    driver.get('https://tn003.nimbi.com.br/RedeNimbiTodos/Negociation.aspx')
    time.sleep(5)    # Pause 5.5 seconds
    #BUSCA PROCESSO
    searchBarProcesso = driver.find_element(by=By.CSS_SELECTOR, value='[data-webbtests="RedeNimbiToDos.Negociation.wblFormGenericSearchBoxBlock.txtSearchInput"]')
    driver.execute_script("arguments[0].style.border='2px solid red'", searchBarProcesso)
    searchBarProcesso.send_keys(pedido)
    searchBarProcesso.send_keys(Keys.RETURN)
    time.sleep(5) 
    #CLICA PROCESSO
    processoResult = driver.find_elements(by=By.ID, value="wt1_Huge_WebbBaseTheme_wt8_block_wtMainContent_wtMainContent_NegociaWeb_wt2_block_Huge_WebbBaseTheme_wtwblLayout_ListEdit_block_wt22_wtArea_Col_2_wtMainContent_wtlstTradingPhaseTable_ctl00_Huge_WebbBaseTheme_wt101_block_wt27_wtArea_Col_1_wt45_wtArea_Col_1_wt41_wtTitle_wtTitle_wtexp_AuctionTitle2")
    if len(processoResult) == 0 :  continue
    driver.execute_script("arguments[0].style.border='2px solid red'", processoResult[0])
    processoResult[0].click()
    time.sleep(15)
    mensagemFRQ = driver.find_elements(by=By.ID, value="wt3_Huge_WebbBaseTheme_wt17_block_wt22_RichWidgets_wt21_block_wtSanitizedHtml")
    if len(mensagemFRQ) > 0 :
        createOrcamento(Orcamento(
            rfq=pedido,
            titulo_cotacao="",
            descricao_longa=mensagemFRQ[0].get_attribute("innerText"),
            quantidade=0,
            data_inicio="",
            hora_inicio="",
            data_fim="",
            hora_fim="",
            endereco="",
            comentario="",
            moeda="",
            status="",
            unidade=""
        )) 
        continue

    #BUSCA HORA INICIO
    divHorasInicio = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox.expStartDateTime"]')
    horaInicio = divHorasInicio.get_attribute('innerHTML').split(" ")[1]
    #BUSCA DATA INICIO
    divDataInicio = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox.expStartDateTime"]')
    dataInicio = divDataInicio.get_attribute('innerHTML').split(" ")[0]
    #TITULO    
    divTitulo = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.expRequestTitle"]')
    titulo = divTitulo.get_attribute("innerText")
    #STATUS 
    divStatus= driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.Layout_MainContent.expStatus"]')
    status = divStatus.get_attribute("innerText")
    #BUSCA HORA VENCIMENTO
    divHoras = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox2.expEndDateTime"]')
    horaVencimento = divHoras.get_attribute('innerHTML').split(" ")[1]
    #BUSCA DATA VENCIMENTO
    divDataVencimento = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox2.expEndDateTime"]')
    dataVencimento = divDataVencimento.get_attribute('innerHTML').split(" ")[0]
    while True:
        #CLICA NO OBJECTO BUSCADO
        links = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.tblTableItems.lnkCreateOrUpdateItemRFQ"]')
        for index, link in enumerate(links):
            overlay = driver.find_element(By.ID, 'wt4_Huge_WebbBaseTheme_wt19_block_wtMainContent_wtMainContent_NegociaRFxWeb_wt2_block_wt79_Huge_WebbBaseTheme_wt10_block_wtMainContent_wtMainContent_wtListCycle_ctl00_wt102_wt31_Huge_WebbBaseTheme_wt18_block_wtCollapsibleContentPH_Huge_WebbBaseTheme_wt27_block_wtBox_wtContent_wtItemsWB_Huge_WebbBaseTheme_wt129_block_wtBox_Huge_WebbBaseTheme_wt27_block_wtArea_Col_1_Huge_WebbBaseTheme_wt122_block_wtField')
            actions.move_to_element(overlay).perform()
            actions.move_to_element(links[index]).perform()
            links[index].click()
            time.sleep(3)    
            frame = driver.find_element(By.TAG_NAME, 'iframe')
            driver.switch_to.frame(frame)
            #DESCRICAO LONGA
            divDescricaoLonga = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt410_block_wtArea_Col_1_Huge_WebbBaseTheme_wt466_block_wtField")
            driver.execute_script("arguments[0].style.border='2px solid red'", divDescricaoLonga)
            span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divDescricaoLonga.get_attribute('innerHTML'))
            descricaoLongaStr = span_texts[len(span_texts)-1]
            #MOEDA 
            divMoeda= driver.find_element(By.ID, 'wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt269_block_wtArea_Col_1_Huge_WebbBaseTheme_wt365_block_wtField')
            moedaCotacao = divMoeda.get_attribute("innerText")
            #QUANTIDADE
            divTotal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt2_block_wtArea_Col_2_Huge_WebbBaseTheme_wt266_block_wtField")
            driver.execute_script("arguments[0].style.border='2px solid red'", divTotal)
            span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divTotal.get_attribute('innerHTML'))
            divTotalStr = span_texts[len(span_texts)-1]
            #UNIDADE
            divUnidade = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt2_block_wtArea_Col_1_Huge_WebbBaseTheme_wt15_block_wtField")
            driver.execute_script("arguments[0].style.border='2px solid red'", divUnidade)
            span_texts_unidade = re.findall(r'<span.*?>(.*?)<\/span>', divUnidade.get_attribute('innerHTML'))
            divUnidadeStr = span_texts_unidade[len(span_texts_unidade)-1]
            #PREÇO
            divPreco = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt2_block_wtArea_Col_2_Huge_WebbBaseTheme_wt266_block_wtField")
            driver.execute_script("arguments[0].style.border='2px solid red'", divPreco)
            span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divPreco.get_attribute('innerHTML'))
            divPrecoStr = span_texts[len(span_texts)-1]
            #LOCAL
            divLocal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt217_block_wtBox_Huge_WebbBaseTheme_wt162_block_wtList_Huge_WebbBaseTheme_wt590_block_wtListItem_wtLknDelivery")
            driver.execute_script("arguments[0].style.border='2px solid red'", divLocal)
            divLocal.click()
            time.sleep(2)    
            divLocal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_wt435_Huge_WebbBaseTheme_wt18_block_wtArea_Col_1_Huge_WebbBaseTheme_wt14_block_wtField_Huge_WebbBaseTheme_wt35_block_wtBox")
            driver.execute_script("arguments[0].style.border='2px solid red'", divLocal)
            span_texts_local = re.findall(r'<span.*?>(.*?)<\/span>', divLocal.get_attribute('innerHTML'))
            local = span_texts_local[len(span_texts)-1]
            #comentarios
            divComentario = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt217_block_wtBox_Huge_WebbBaseTheme_wt162_block_wtList_Huge_WebbBaseTheme_wt232_block_wtListItem_wtLknComment")
            driver.execute_script("arguments[0].style.border='2px solid red'", divComentario)
            divComentario.click()
            time.sleep(2)    
            divContentComentario = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="NegociaRFxWeb.RFQ_ParticipantQuotation_Popup_NEW.wblBox25.divContainer2"]')
            span_texts_comentarios = re.findall(r'<span.*?>(.*?)<\/span>', divContentComentario[0].get_attribute('innerHTML') if len(divContentComentario) == 1 else "".join([div.get_attribute('innerHTML') for div in divContentComentario]))
            comentarios = span_texts_comentarios
            # Atualizando a célula
            orcamentoCriado = Orcamento(
                rfq=pedido,
                titulo_cotacao=titulo,
                descricao_longa=descricaoLongaStr,
                quantidade=float(divTotalStr.replace('.', '').replace(',', '.')),
                data_inicio=dataInicio,
                hora_inicio=horaInicio,
                data_fim=dataVencimento,
                hora_fim=horaVencimento,
                endereco=local,
                comentario=";".join(comentarios),
                moeda=moedaCotacao.split("-")[1].strip(),
                status=status,
                unidade=divUnidadeStr
            )
            print(orcamentoCriado.titulo_cotacao, orcamentoCriado.data_fim)
            createOrcamento(orcamentoCriado)
            fimProcesso = time.time()
            tempoTotal = fimProcesso - comecoProcesso
            listaPedidosColetados.append(pedido)
            driver.switch_to.default_content()
            driver.find_element(By.CLASS_NAME, 'os-internal-ui-dialog-titlebar-close').click()
            if(index == len(links)):
                time.sleep(5)
        nextButton = driver.find_elements(by=By.CLASS_NAME, value='ListNavigation_Next')
        if(len(nextButton) > 0):
            links.clear()
            nextButton[0].click()
            time.sleep(5)
        else: break

print('fim:', datetime.now().strftime("%Y-%m-%d %H:%M:%S"), len(listaPedidosColetados), ' pedidos coletados.')