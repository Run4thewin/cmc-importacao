from flask import Flask, request, jsonify
from email.mime.text import MIMEText
import smtplib

app = Flask(__name__)

# Configurações de e-mail da Locaweb
SMTP_SERVER = 'smtp.cmcimportacao.com.br'  # Substitua pelo servidor SMTP correto da Locaweb
SMTP_PORT = 587  # Porta para TLS
SMTP_USER = 'cotacao@cmcimportacao.com.br'  # Substitua com seu e-mail Locaweb
SMTP_PASSWORD = 'Cmc@12345'  # Senha do seu e-mail

# Rota para enviar o e-mail
@app.route('/send-email', methods=['POST'])
def send_email(html, Subject, to):
    
    # Cria a mensagem
    msg = MIMEText(html)
    msg['Subject'] = Subject
    msg['From'] = SMTP_USER
    msg['To'] = to

    # Conecta ao servidor SMTP da Locaweb
    server = smtplib.SMTP(SMTP_SERVER, SMTP_PORT)
    server.starttls()
    server.login(SMTP_USER, SMTP_PASSWORD)
    
    # Envia o e-mail
    server.sendmail(SMTP_USER, [to], msg.as_string())
    server.quit()
        