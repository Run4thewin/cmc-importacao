from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
import json 
from bs4 import BeautifulSoup
import time
import re
import timeit
import pandas as pd
import csv
from google.oauth2 import service_account
from googleapiclient.discovery import build
import pandas as pd
from datetime import datetime, timedelta
import time
from db import createOrcamento, Orcamento, getListImportacao, getListOrcamento
import os
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build

# ID da planilha (encontrado na URL da planilha)
SPREADSHEET_ID = '1C0eKMJzvriK8af-I4mw-S1REXgWHm_dRYhuhM8Pz8ik'

# Intervalo dos dados que você deseja ler
RANGE_NAME = 'BANCO DE DADOS!A1'  # Exemplo: 'Sheet1!A1:D10'

# Autenticação
def get_service():

    #######SHEETS SETUP
    # Caminho para o seu arquivo de credenciais JSON
    SERVICE_ACCOUNT_FILE = './chave-autenticacao/inbound-planet-433713-i1-1c93e8b0f367.json'
    # Escopos necessários
    SCOPES = ['https://www.googleapis.com/auth/spreadsheets', 'https://www.googleapis.com/auth/drive']

    # Criando credenciais a partir do arquivo da conta de serviço
    creds = service_account.Credentials.from_service_account_file(
        SERVICE_ACCOUNT_FILE, scopes=SCOPES)

    # Conectando à API do Google Sheets
    sheetsService = build('sheets', 'v4', credentials=creds)    
    
    return sheetsService

service = get_service()
sheet = service.spreadsheets()


# Dados a serem adicionados (uma linha com várias colunas)
values = []




rfqsOrcamento = getListOrcamento("where data_fim = '2024-09-19'")

for item in rfqsOrcamento:
    values.append(
        [
            "VALE S.A.", 
            "33592510000154", 
            item['rfq'], 
            item['status'], 
            item['titulo_cotacao'], 
            item['data_inicio'], 
            item['data_fim'],
            "",
            "",
            f'{item['descricao_longa']} comentarios: {item['comentario']}',
            item['quantidade'],
            0,
            0,
            item['moeda'],
            "",
            "Não",
            "Não",
            "Não",
            item['endereco'],
            item['hora_fim'].strftime("%H:%M:%S"),
        ]
    )
# Configuração do corpo da solicitação
body = {
    'values': values
}

sheet.values().append(
        spreadsheetId=SPREADSHEET_ID,
        range=RANGE_NAME,
        valueInputOption='RAW',  # ou 'USER_ENTERED' para respeitar formatação do usuário
        body=body
    ).execute()