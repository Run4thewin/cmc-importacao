import pandas as pd
from db import createContact, Contact

# Replace 'your_file.xlsx' with the path to your file
file_path = 'FORNECEDORES.xlsx'

# Read the Excel file into a DataFrame
df = pd.read_excel(file_path, )

listToAdd = []
# Iterate over each row using itertuples()
for row in df.itertuples(index=True, name='Pandas'):
    if(not isinstance(row.NOME, float)):
        contact = Contact(
                nome=row.NOME, 
                email=row._4 if not isinstance(row._4, float) else "", 
                email2= row._5 if not isinstance(row._5, float) else "", 
                email3= row._6 if not isinstance(row._6, float) else "", 
                phone= row._7 if not isinstance(row._7, float) else "",
                cellular= row.CELULAR if not isinstance(row.CELULAR, float) else ""
                )
        createContact(contact)
    


