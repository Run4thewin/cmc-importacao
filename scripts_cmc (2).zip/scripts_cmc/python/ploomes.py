import requests
from db import Orcamento
import json
from decimal import Decimal
from datetime import date, time, datetime
import time


def getUnidade(unidade):
    if(unidade == "Metro"):
        return 1100097638
    if(unidade == "peça"):
        return 1100097637
    if(unidade == "Unidade"):
        return 1100097639

class OrcamentoPloomes:
    def __init__(self, rfq, title, stageId, descricao_longa, quantidade=None, data_inicio=None, hora_inicio=None, 
                data_fim=None, hora_fim=None, endereco=None, comentario=None, moeda=None, status=None, unidade=None):
        self.rfq = rfq  # Título do orçamento
        self.title = title  # Título do orçamento
        self.stageId = stageId  # ID do estágio do orçamento
        self.descricao_longa = descricao_longa  # Descrição detalhada do orçamento
        self.quantidade = quantidade  # Quantidade relacionada ao orçamento (opcional)
        self.data_inicio = data_inicio  # Data de início do orçamento (opcional)
        self.hora_inicio = hora_inicio  # Hora de início do orçamento (opcional)
        self.data_fim = data_fim  # Data de término do orçamento (opcional)
        self.hora_fim = hora_fim  # Hora de término do orçamento (opcional)
        self.endereco = endereco  # Endereço relacionado ao orçamento (opcional)
        self.comentario = comentario  # Comentários adicionais (opcional)
        self.moeda = moeda  # Moeda usada no orçamento (opcional)
        self.status = status  # Status do orçamento (opcional)
        self.unidade = unidade  # Status do orçamento (opcional)
        
    def to_dict(self):
        return {
            'rfq': self.rfq,
            'title': self.title,
            'stageId': self.stageId,
            'descricao_longa': self.descricao_longa,
            'quantidade': float(self.quantidade),
            'data_inicio': self.data_inicio.isoformat() if self.data_inicio else None,  # Converter date para string
            'hora_inicio': self.hora_inicio.strftime('%H:%M:%S') if self.hora_inicio else None,  # Converter time para string
            'data_fim': self.data_fim.isoformat() if self.data_fim else None,  # Converter date para string
            'hora_fim': self.hora_fim.strftime('%H:%M:%S') if self.hora_fim else None,  # Converter time para string
            'endereco': self.endereco,
            'comentario': self.comentario,
            'moeda': self.moeda,
            'status': self.status
        }
    

            
    def to_ploomes(self):
        return {
            "Title": self.title,
            "StageId": 110012824,
            "ContactId":1100177857,
            "OtherProperties": [
                {
                    "FieldKey":"deal_DDF55206-93D7-4223-93F1-B23AFD3FD24D",
                    "StringValue": self.rfq
                },
                {
                    "FieldKey":"deal_6403820D-2F97-4CFB-879C-7C0132623672",
                    "BigStringValue": self.comentario
                },
                {
                    "FieldKey":"deal_42BFC914-7E86-4433-BE13-0A1CA8B15677",
                    "BigStringValue": self.descricao_longa
                },
                {
                    "FieldKey": "deal_63B0E6C6-F744-4646-AB0B-9ACCA1CDA77D",
                    "IntegerValue": float(self.quantidade)
                },
                {
                    "FieldKey": "deal_DA4B272C-B90D-48AE-AD3F-2871C788A8EF",
                    "DateTimeValue": self.data_fim.isoformat()
                },
                {
                    "FieldKey": "deal_7C788ADE-FD32-408B-A6C2-7B92E2ACD2CC",
                    "DateTimeValue": self.hora_fim.isoformat()
                },
                {
                    "FieldKey": "deal_EB5AC5A2-10FC-4C66-8F90-F65444B5B3EC",
                    "StringValue": self.unidade
                }
            ]
        }
        
        

def criar_pipeline_ploomes(api_key, nome_pipeline, orcamento: OrcamentoPloomes):
    url = "https://api2.ploomes.com/Deals"  # Endpoint da API para criação de pipelines

    headers = {
        "User-Key": api_key,
        "Content-Type": "application/json; odata.metadata=minimal"
    }
    print(orcamento)
    # Faz a requisição POST
    response = requests.post(url, json=orcamento, headers=headers)
    
    # Verifica se a requisição foi bem-sucedida
    if response.status_code == 200:
        return response.json()  # Retorna os dados do pipeline criado
    else:
        print(f"Erro ao criar pipeline. Status code: {response.status_code}")
        print(f"Detalhes: {response.text}")
        return None

# Exemplo de uso
api_key = "D3BBCB6B1ED869ECCE2A3DCD8B107DC1CC7F4A8807CE52763840FF3F27B9AE733DB366E36EE71ABE0A7889FF7B963643BA7F7225A002FC16980836DCA7746100"  # Substitua pela sua chave de API
nome_pipeline = "Novo Pipeline Comercial"


def delete_pipeline_ploomes(id):
    url = f"https://api2.ploomes.com/Deals({id})"  # Endpoint da API para criação de pipelines

    headers = {
        "User-Key": api_key,
        "Content-Type": "application/json; odata.metadata=minimal"
    }

    # Faz a requisição POST
    response = requests.delete(url, headers=headers)
    
    # Verifica se a requisição foi bem-sucedida
    if response.status_code == 200:
        print(f"Pipeline '{id}' deletado com sucesso.")
    else:
        print(f"Erro ao criar pipeline. Status code: {response.status_code}")
        print(f"Detalhes: {response.text}")
        return None





def criar_orcamento(orcamento: OrcamentoPloomes):
    criar_pipeline_ploomes(api_key, nome_pipeline, orcamento)

def buscarPipes():
    url = f"https://api2.ploomes.com/Deals?$filter=OwnerId eq null"  # Endpoint da API para criação de pipelines

    headers = {
        "User-Key": api_key,
        "Content-Type": "application/json; odata.metadata=minimal"
    }

    # Faz a requisição POST
    response = requests.get(url, headers=headers)
    # Verifica se a requisição foi bem-sucedida
    if response.status_code == 200:
        return response.json()["value"]
    else:
        print(f"Erro ao criar pipeline. Status code: {response.status_code}")
        print(f"Detalhes: {response.text}")
        return None
