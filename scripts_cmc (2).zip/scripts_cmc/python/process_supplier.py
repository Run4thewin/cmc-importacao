import pandas as pd
from db import createSupplier

# Replace 'your_file.xlsx' with the path to your file
file_path = 'FORNECEDORES.xlsx'

# Read the Excel file into a DataFrame
df = pd.read_excel(file_path, )


# Iterate over each row using itertuples()
for row in df.itertuples(index=True, name='Pandas'):
    if(not isinstance(row.REPRESENTANTE, float)):
        createSupplier(row.REPRESENTANTE)
    

