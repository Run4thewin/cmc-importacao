from db import get_suppliers, get_manufactors, create_manufacture_suplier, get_contacts, create_contact_supplier
from planilha_fornecedor import get_df
import pandas as pd


dados_planilha = get_df()
contacts = get_contacts()
listaSupplier = get_suppliers()


df_selected_names = pd.DataFrame(dados_planilha)


df_contacts = pd.DataFrame(contacts)

dfSupp = pd.DataFrame(listaSupplier)


print(dfSupp)
listAddDB = []

listContact = df_contacts[['id', 'email']].values.tolist()

for contact in listContact:
    filterNames = df_selected_names[df_selected_names['_4'].isin([contact[1]])]['REPRESENTANTE'].tolist()
    for name in filterNames:
        suppId = dfSupp[dfSupp['name_supplier'].isin([name])]['id'].tolist()

        if(not isinstance(name, float)):
            create_contact_supplier(contact[0], suppId[0])