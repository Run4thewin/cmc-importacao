CREATE TABLE Products (
    id INT PRIMARY KEY IDENTITY(1,1),
    name NVARCHAR(255) NOT NULL,
    partnumber NVARCHAR(100) UNIQUE NOT NULL,
    value DECIMAL(10, 2) NOT NULL,
    updated_date DATETIME DEFAULT GETDATE(),
    short_description NVARCHAR(255),
    long_description NVARCHAR(MAX)
);