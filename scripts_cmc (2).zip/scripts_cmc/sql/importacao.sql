CREATE TABLE IMPORTACAO (
	rfq VARCHAR(50) PRIMARY KEY,
	data_importacao datetime default getdate(),
	sistema VARCHAR(150) not null
);