DROP TABLE supplier_contact;
CREATE TABLE supplier_contact (
    id_contact int not null,
    id_supplier int not null
);

GRANT SELECT, INSERT, UPDATE, DELETE ON supplier_contact TO CMC_API;
