-- Tabela de Permissões dos Perfis
CREATE TABLE menu_permissions (
    permission_id INT,
    menu_item_id INT,
    PRIMARY KEY (menu_item_id, permission_id),
    FOREIGN KEY (menu_item_id) REFERENCES menu_item(profile_id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE
);