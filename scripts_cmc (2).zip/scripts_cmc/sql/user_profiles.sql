-- Tabela de Perfis dos Usuários
CREATE TABLE user_profiles (
    user_id INT,
    profile_id INT,
    assigned_at DATETIME DEFAULT GETDATE(),
    PRIMARY KEY (user_id, profile_id),
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (profile_id) REFERENCES profiles(profile_id) ON DELETE CASCADE
);