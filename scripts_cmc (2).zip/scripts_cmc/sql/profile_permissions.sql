-- Tabela de Permissões dos Perfis
CREATE TABLE profile_permissions (
    profile_id INT,
    permission_id INT,
    granted_at DATETIME DEFAULT GETDATE(),
    PRIMARY KEY (profile_id, permission_id),
    FOREIGN KEY (profile_id) REFERENCES profiles(profile_id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(permission_id) ON DELETE CASCADE
);