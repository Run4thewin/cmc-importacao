CREATE TABLE Company (
    id INT PRIMARY KEY IDENTITY(1,1),
    name_company NVARCHAR(100) NOT NULL,
    cnpj CHAR(14) NOT NULL,
    email NVARCHAR(100) NOT NULL,
    description_company Text NOT NULL,
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);