DROP TABLE supplier;

CREATE TABLE supplier (
    id INT PRIMARY KEY IDENTITY(1,1),
    name_supplier NVARCHAR(255) NOT NULL,
    cnpj CHAR(14),
);

GRANT SELECT, INSERT, UPDATE, DELETE ON supplier TO CMC_API;