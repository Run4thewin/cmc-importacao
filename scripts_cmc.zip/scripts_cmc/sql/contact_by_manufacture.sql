select cont.name_contact, cont.email, cont.email2, cont.email3
from manufacture_supplier man_sup
	inner join manufacture manu 
		on man_sup.id_manufacture = manu.id
	inner join supplier supp
		on man_sup.id_supplier = supp.id
	inner join supplier_contact supp_cont
		on supp_cont.id_supplier = supp.id
	inner join contact cont
		on supp_cont.id_contact = cont.id
where manu.id = 1
