DROP TABLE ORCAMENTO;
CREATE TABLE ORCAMENTO (
    rfq VARCHAR(50),           -- Assumindo que o campo rfq é único
    titulo_cotacao NVARCHAR(255),          -- Título da cotação
    descricao_longa NVARCHAR(MAX),         -- Descrição longa (texto grande)
    quantidade DECIMAL(10, 2),                    -- Quantidade solicitada
    data_inicio DATE,                      -- Data de início
    hora_inicio TIME,                      -- Hora de início
    data_fim DATE,                         -- Data de término
    hora_fim TIME,                         -- Hora de término
    endereco NVARCHAR(MAX),                -- Endereço do pedido
    comentario NVARCHAR(MAX),              -- Comentários adicionais
    moeda CHAR(3),                         -- Código da moeda (ISO 4217)
    status NVARCHAR(50),                   -- Status do orçamento
    unidade NVARCHAR(50),                   -- Unidade de medida
	DATA_IMPORTACAO DATETIME DEFAULT GETDATE()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON ORCAMENTO TO CMC_API