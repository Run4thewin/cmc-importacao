-- Tabela de Permissões
CREATE TABLE permissions (
    permission_id INT IDENTITY(1,1) PRIMARY KEY,
    permission_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);

INSERT INTO permissions (permission_name, description)
VALUES ('VIEW_DASHBOARD', 'Permission to view the dashboard'),
       ('EDIT_USERS', 'Permission to edit user information');

DECLARE @profile_id INT = (SELECT profile_id FROM profiles WHERE profile_name = 'Admin');
DECLARE @permission_id1 INT = (SELECT permission_id FROM permissions WHERE permission_name = 'VIEW_DASHBOARD');
DECLARE @permission_id2 INT = (SELECT permission_id FROM permissions WHERE permission_name = 'EDIT_USERS');

INSERT INTO profile_permissions (profile_id, permission_id)
VALUES (@profile_id, @permission_id1),
       (@profile_id, @permission_id2);

-- Associar perfil ao usuário
DECLARE @user_id INT = (SELECT user_id FROM users WHERE username = 'john_doe');

INSERT INTO user_profiles (user_id, profile_id)
VALUES (@user_id, @profile_id);