-- Tabela de Perfis
CREATE TABLE profiles (
    profile_id INT IDENTITY(1,1) PRIMARY KEY,
    profile_name VARCHAR(50) NOT NULL UNIQUE,
    description VARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    updated_at DATETIME DEFAULT GETDATE()
);

INSERT INTO profiles (profile_name, description)
VALUES ('Admin', 'Administrator profile with full access');