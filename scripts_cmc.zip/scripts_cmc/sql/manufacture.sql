DROP TABLE manufacture;

CREATE TABLE manufacture (
    id INT PRIMARY KEY IDENTITY(1,1),
    name_manufacture NVARCHAR(255) NOT NULL,
    cnpj CHAR(14),
);

GRANT SELECT, INSERT, UPDATE, DELETE ON manufacture TO CMC_API;