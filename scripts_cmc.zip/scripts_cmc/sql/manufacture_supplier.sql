DROP TABLE manufacture_supplier;
CREATE TABLE manufacture_supplier (
    id_manufacture int not null,
    id_supplier int not null
);

GRANT SELECT, INSERT, UPDATE, DELETE ON manufacture_supplier TO CMC_API;
