CREATE TABLE automate_email (
    id INT PRIMARY KEY IDENTITY(1,1),
    email_to NVARCHAR(100) NOT NULL,
    html CHAR(14) NOT NULL,
    status_email CHAR(14) NOT NULL default 1,
    created_at datetime default getdate(),
    updated_at datetime
);


grant select, insert, update, delete on automate_email to cmc_api;