from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
import json 
from bs4 import BeautifulSoup
import time
import re
import timeit
import pandas as pd
import csv
from google.oauth2 import service_account
from googleapiclient.discovery import build
import pandas as pd
from datetime import datetime, timedelta
import time
import subprocess


# Caminho para o seu arquivo de credenciais JSON
SERVICE_ACCOUNT_FILE = 'chave-autenticacao/inbound-planet-433713-i1-1c93e8b0f367.json'

# Escopos necessários
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# Criando credenciais a partir do arquivo da conta de serviço
creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# ID da planilha (encontrado na URL da planilha)
SPREADSHEET_ID = '1mUFdXNgtiJWhNUBr1Qk1JPDK4ktkETgQA4gtY5qo4sg'
SPREADSHEET_CONTACT_ID = '1ll9Eu4lrHqo2Sx-lMj0gRz55EGzM2R55_RYXAklijv4'

SHEET_ID = 0  # The sheet ID, typically 0 for the first sheet


# Conectando à API do Google Sheets
sheetsService = build('sheets', 'v4', credentials=creds)


pedidoResult = (
        sheetsService.spreadsheets()
        .values()
        .get(spreadsheetId=SPREADSHEET_ID, 
            range=f'BANCO_DE_DADOS!A:L')
        .execute())

contatosResult = (sheetsService.spreadsheets()
        .values()
        .get(spreadsheetId=SPREADSHEET_CONTACT_ID, 
            range=f'Sheet1!A:F')
        .execute())


# Extract values from the result
valuesPedido = pedidoResult.get('values', [])
# Extract values from the result
valuesContato = contatosResult.get('values', [])


# Manually define column names since the sheet data does not have headers
column_names = [
    'Pedido ID', 
    'Cliente Nome',
    'Descricao completa', 
    'Quantidade', 
    'Data Inicio', 
    'Hora Inicio', 
    'Data Fim', 
    'Hora Fim', 
    'Endereco', 
    'Comentarios', 
    'moeda', 
    'Status']

# Create DataFrame with custom column names
df = pd.DataFrame(valuesPedido, columns=column_names)


# Create DataFrame with custom column names
dfC = pd.DataFrame(valuesContato, columns=['frabricante', 'nome', 'email', 'email2', 'telefone','celular'])
empresas = dfC['frabricante'].tolist()

for data in df.values:
    print(data)