from db import *
from send_mail import send_email

quotList = getListOrcamento()
manufactureList = get_manufactors()

listMan = []
for quot in quotList:
    texto = f'{quot['descricao_longa']} {quot['comentario']}'
    manufactureNameId = next((item['id'] for item in manufactureList if item['name_manufacture'] in texto), None)
    if(manufactureNameId != None):  
        contact = get_list_contact_by_manufacture(manufactureNameId)
        if(len(contact)>0):
            listMan.append({"text": texto, "contact": contact})
            
for item in listMan[:1]:
    send_email(str(item), "teste", 'santos.gabriel.mail@gmail.com')
    print(item)
        