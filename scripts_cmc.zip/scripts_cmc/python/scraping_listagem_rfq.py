from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
from google.oauth2 import service_account
from googleapiclient.discovery import build
import pandas as pd
import time
from db import createImportacao, Importacao, getListImportacao


#CrisCaio#1DeusCmC
#vendas@cmcimportacao.com.br
login = "vendas@cmcimportacao.com.br"#input("Digite o login:")
password = "CrisCaio#1DeusCmC"#input("Digite a senha:") 


##SHEETS
#######SHEETS SETUP
# Caminho para o seu arquivo de credenciais JSON
SERVICE_ACCOUNT_FILE = 'chave-autenticacao/inbound-planet-433713-i1-1c93e8b0f367.json'
# Escopos necessários
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# Criando credenciais a partir do arquivo da conta de serviço
creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# ID da planilha (encontrado na URL da planilha)
SPREADSHEET_ID = '1mUFdXNgtiJWhNUBr1Qk1JPDK4ktkETgQA4gtY5qo4sg'

# Intervalo dos dados que você deseja ler
RANGE_NAME = 'BANCO_DE_DADOS!A1'  # Exemplo: 'Sheet1!A1:D10'


# Conectando à API do Google Sheets
sheetsService = build('sheets', 'v4', credentials=creds)

# Chamando a API para buscar os dados
sheet = sheetsService.spreadsheets()

formula = '=QUERY(A2:M, "SELECT * WHERE L > DATE \'2024-08-23\'", 1)'
# Corpo da requisição para adicionar a fórmula
body = {
    'values': [[formula]]
}



#=========login
service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
driver.maximize_window()
driver.get("https://login.nimbi.com.br/")
#PREENCHE EMAIL
emailField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtUsernameField")
driver.execute_script("arguments[0].style.border='2px solid red'", emailField)
emailField.send_keys(login)
#CLICA BOTAO LOGIN EMAIL
sendButton = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtFirstStep")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButton)
sendButton.click()
time.sleep(1.5)    # Pause 5.5 seconds
#ENTRANDO COM SENHA
passwordField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtinpPassword")
driver.execute_script("arguments[0].style.border='2px solid red'", passwordField)
passwordField.send_keys(password)
#CLICA BOTAO LOGIN SENHA
sendButtonPass = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtSignin")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButtonPass)
sendButtonPass.click()
time.sleep(50)    # Pause 5.5 seconds

driver.get('https://tn003.nimbi.com.br/RedeNimbiTodos/Negociation.aspx')


while(1==1):
    result = sheet.values().get(spreadsheetId=SPREADSHEET_ID, range='BANCO_DE_DADOS!A:A').execute()
    values = result.get('values', [])
    sheetsSize = len(values)
    
    # Manually define column names since the sheet data does not have headers
    column_names = ['Pedido ID']

    # Create DataFrame with custom column names
    df = pd.DataFrame(values, columns=column_names)

    time.sleep(10)
    rfqs = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="RedeNimbiToDos.Negociation.wblSearchGenericAuction.expAuctionDescription"]')
    listAdicionar = []
    for index, frq in enumerate(rfqs):
        fqCode = frq.get_attribute("innerText").split("-")[1].strip()
        if fqCode not in df['Pedido ID'].values:
            listAdicionar.append(fqCode)
    for rqfAdd in listAdicionar:
        rfqsBanco = getListImportacao()
        # Create DataFrame with custom column names
        df = pd.DataFrame(rfqsBanco, columns=['rfq'])
        if rqfAdd not in df['rfq'].tolist():
            createImportacao(Importacao(rfq=rqfAdd, sistema='nimbi'))
    
    driver.find_element(by=By.CLASS_NAME, value='ListNavigation_Next').click()

