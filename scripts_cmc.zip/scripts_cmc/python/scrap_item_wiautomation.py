from selenium import webdriver
from selenium.webdriver.common.by import By
import time
import re

def scrap_item(driver, href_item):
    print("Buscando url:", driver.current_url)
    driver.get(href_item)
  
    image = driver.find_element(By.CLASS_NAME, "zoomImg")
    brand = driver.find_element(By.CLASS_NAME, "main_info_details")
    name = driver.find_element(By.CLASS_NAME, "product_name")
    priceDiv = driver.find_elements(By.CLASS_NAME, "main_product_price")
    description = driver.find_element(By.CLASS_NAME, "description")
    
    if(len(priceDiv)  == 0): price = ""   
    else: price = priceDiv[0].get_attribute("innerText")
    
    span_texts = re.findall(r'<span.*?>(.*?)<\/span>', brand.get_attribute("innerHTML"))
    
    return {
            "image": image.get_attribute("src"), 
            "brand": span_texts[1], 
            "sku": span_texts[3],
            "name": name.get_attribute("innerText"),
            "price": price,
            "description": description.get_attribute("innerText"),
            "url": driver.current_url
        }
        
