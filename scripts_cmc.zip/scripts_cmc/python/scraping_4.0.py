from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.common.keys import Keys
import json 
from bs4 import BeautifulSoup
import time
import re
import timeit
import pandas as pd
import csv
from google.oauth2 import service_account
from googleapiclient.discovery import build
import pandas as pd
from datetime import datetime, timedelta
import time

login = "vendas@cmcimportacao.com.br"
senha = "CrisCaio#1DeusCmC"

#login = input("Digite o Login: ")
#senha = input("Digite a Senha: ")


print('Incio:', datetime.now().strftime("%Y-%m-%d %H:%M:%S"))

# DATA BASE
data_antecedente = datetime.now() - timedelta(days=2)

#######SHEETS SETUP
# Caminho para o seu arquivo de credenciais JSON
SERVICE_ACCOUNT_FILE = 'chave-autenticacao/inbound-planet-433713-i1-1c93e8b0f367.json'
# Escopos necessários
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']

# Criando credenciais a partir do arquivo da conta de serviço
creds = service_account.Credentials.from_service_account_file(
    SERVICE_ACCOUNT_FILE, scopes=SCOPES)

# ID da planilha (encontrado na URL da planilha)
SPREADSHEET_ID = '1mUFdXNgtiJWhNUBr1Qk1JPDK4ktkETgQA4gtY5qo4sg'

# Intervalo dos dados que você deseja ler
RANGE_NAME = 'BANCO_DE_DADOS!A1'  # Exemplo: 'Sheet1!A1:D10'

# Conectando à API do Google Sheets
sheetsService = build('sheets', 'v4', credentials=creds)

# Chamando a API para buscar os dados
sheet = sheetsService.spreadsheets()

result = (
    sheetsService.spreadsheets()
    .values()
    .get(spreadsheetId=SPREADSHEET_ID, 
         range=RANGE_NAME)
    .execute())
values = result.get('values', [])


df = pd.DataFrame(values[1:], columns=values[0])
# Converter a coluna de datas para o tipo datetime
df['Data de Término da Cotação'] = pd.to_datetime(df['Data de Término da Cotação'], format='%d/%m/%Y', errors='coerce')

# Ordenar o DataFrame pela coluna de datas
df = df.sort_values(by='Data de Término da Cotação')

# Converter DataFrame ordenado para lista de listas
lista_de_listas = df.values.tolist()
sheetsSize = len(lista_de_listas) + 1

df_filtrado = df[df['Data de Término da Cotação'] > data_antecedente]

service = Service(ChromeDriverManager().install())
driver = webdriver.Chrome(service=service)
driver.maximize_window()
driver.get("https://login.nimbi.com.br/")
#PREENCHE EMAIL
emailField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtUsernameField")
driver.execute_script("arguments[0].style.border='2px solid red'", emailField)
emailField.send_keys(login)
#CLICA BOTAO LOGIN EMAIL
sendButton = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtFirstStep")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButton)
sendButton.click()
time.sleep(1.5)    # Pause 5.5 seconds
#ENTRANDO COM SENHA
passwordField = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtinpPassword")
driver.execute_script("arguments[0].style.border='2px solid red'", passwordField)
passwordField.send_keys(senha)
#CLICA BOTAO LOGIN SENHA
sendButtonPass = driver.find_element(by=By.NAME, value="wtLayout_Normal_2Col$wtLoginElements$wtLoginWB_V2$wt16$wtSignin")
driver.execute_script("arguments[0].style.border='2px solid red'", sendButtonPass)
sendButtonPass.click()

time.sleep(5)    # Pause 5.5 seconds



listaPedidosColetados = []

while(1==1):
    rfqs = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="RedeNimbiToDos.Negociation.wblSearchGenericAuction.expAuctionDescription"]')
    listAdicionar = []
    print(df)
    for index, frq in enumerate(rfqs):
        fqCode = frq.get_attribute("innerText").split("-")[1].strip()
        pedido = pedido[0]
    indexObjeto = indexAux+1
    print('indexObjeto', indexObjeto)
    # Send the request to the Sheets API
    comecoProcesso = time.time()
    posicaoObjeto = listaPedidosColetados.count(pedido)
    print("buscando para pedido:", pedido, '-', posicaoObjeto + 1)
    driver.get('https://tn003.nimbi.com.br/RedeNimbiTodos/Negociation.aspx')
    time.sleep(5)    # Pause 5.5 seconds
    #BUSCA PROCESSO
    searchBarProcesso = driver.find_element(by=By.CSS_SELECTOR, value='[data-webbtests="RedeNimbiToDos.Negociation.wblFormGenericSearchBoxBlock.txtSearchInput"]')
    driver.execute_script("arguments[0].style.border='2px solid red'", searchBarProcesso)
    searchBarProcesso.send_keys(pedido)
    searchBarProcesso.send_keys(Keys.RETURN)
    time.sleep(5) 
    #CLICA PROCESSO
    processoResult = driver.find_elements(by=By.ID, value="wt1_Huge_WebbBaseTheme_wt8_block_wtMainContent_wtMainContent_NegociaWeb_wt2_block_Huge_WebbBaseTheme_wtwblLayout_ListEdit_block_wt22_wtArea_Col_2_wtMainContent_wtlstTradingPhaseTable_ctl00_Huge_WebbBaseTheme_wt101_block_wt27_wtArea_Col_1_wt45_wtArea_Col_1_wt41_wtTitle_wtTitle_wtexp_AuctionTitle2")
    if len(processoResult) == 0 : continue
    driver.execute_script("arguments[0].style.border='2px solid red'", processoResult[0])
    processoResult[0].click()
    time.sleep(15)
    mensagemFRQ = driver.find_elements(by=By.ID, value="wt3_Huge_WebbBaseTheme_wt17_block_wt22_RichWidgets_wt21_block_wtSanitizedHtml")
    if len(mensagemFRQ) > 0 :
        data = [{
                'range': f'BANCO_DE_DADOS!C{indexObjeto}',  
                'values': [[f'{mensagemFRQ[0].get_attribute("innerHTML")} - {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}']],
            }]
        body = {
            'valueInputOption': 'RAW',  # or 'USER_ENTERED'
            'data': data
        }
        result = sheetsService.spreadsheets().values().batchUpdate(
            spreadsheetId=SPREADSHEET_ID,
            body=body
        ).execute()
        print(f"{result.get('totalUpdatedCells')} cells updated.")
        continue

    #BUSCA HORA INICIO
    divHorasInicio = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox.expStartDateTime"]')
    horaInicio = divHorasInicio.get_attribute('innerHTML').split(" ")[1]
    #BUSCA DATA INICIO
    divDataInicio = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox.expStartDateTime"]')
    dataInicio = divDataInicio.get_attribute('innerHTML').split(" ")[0]

    #TITULO    
    divTitulo = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.expRequestTitle"]')
    titulo = divTitulo.get_attribute("innerText")
    #STATUS 
    divStatus= driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.Layout_MainContent.expStatus"]')
    status = divStatus.get_attribute("innerText")
    #BUSCA HORA VENCIMENTO
    divHoras = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox2.expEndDateTime"]')
    horaVencimento = divHoras.get_attribute('innerHTML').split(" ")[1]
    #BUSCA DATA VENCIMENTO
    divDataVencimento = driver.find_element(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.wblFormGenericElementBox2.expEndDateTime"]')
    dataVencimento = divDataVencimento.get_attribute('innerHTML').split(" ")[0]
    #CLICA NO OBJECTO BUSCADO
    links = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="NegociaWeb.InviteDescription_RFQ_Compra.tblTableItems.lnkCreateOrUpdateItemRFQ"]')
    links[posicaoObjeto].click()
    time.sleep(4)    
    frame = driver.find_element(By.TAG_NAME, 'iframe')
    driver.switch_to.frame(frame)
    #DESCRICAO LONGA
    divDescricaoLonga = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt410_block_wtArea_Col_1_Huge_WebbBaseTheme_wt466_block_wtField")
    driver.execute_script("arguments[0].style.border='2px solid red'", divDescricaoLonga)
    span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divDescricaoLonga.get_attribute('innerHTML'))
    descricaoLongaStr = span_texts[len(span_texts)-1]
    #MOEDA 
    divMoeda= driver.find_element(By.ID, 'wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt269_block_wtArea_Col_1_Huge_WebbBaseTheme_wt365_block_wtField')
    moedaCotacao = divMoeda.get_attribute("innerText")
    #QUANTIDADE
    divTotal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt2_block_wtArea_Col_2_Huge_WebbBaseTheme_wt266_block_wtField")
    driver.execute_script("arguments[0].style.border='2px solid red'", divTotal)
    span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divTotal.get_attribute('innerHTML'))
    divTotalStr = span_texts[len(span_texts)-1]
    #PREÇO
    divPreco = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt2_block_wtArea_Col_2_Huge_WebbBaseTheme_wt266_block_wtField")
    driver.execute_script("arguments[0].style.border='2px solid red'", divPreco)
    span_texts = re.findall(r'<span.*?>(.*?)<\/span>', divPreco.get_attribute('innerHTML'))
    divPrecoStr = span_texts[len(span_texts)-1]
    #LOCAL
    divLocal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt217_block_wtBox_Huge_WebbBaseTheme_wt162_block_wtList_Huge_WebbBaseTheme_wt590_block_wtListItem_wtLknDelivery")
    driver.execute_script("arguments[0].style.border='2px solid red'", divLocal)
    divLocal.click()
    time.sleep(4)    
    divLocal = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_wt435_Huge_WebbBaseTheme_wt18_block_wtArea_Col_1_Huge_WebbBaseTheme_wt14_block_wtField_Huge_WebbBaseTheme_wt35_block_wtBox")
    driver.execute_script("arguments[0].style.border='2px solid red'", divLocal)
    span_texts_local = re.findall(r'<span.*?>(.*?)<\/span>', divLocal.get_attribute('innerHTML'))
    local = span_texts_local[len(span_texts)-1]
    #comentarios
    divComentario = driver.find_element(By.ID, value="wt374_Huge_WebbBaseTheme_wt2_block_wtMainContent_wtMainContent_Huge_WebbBaseTheme_wt217_block_wtBox_Huge_WebbBaseTheme_wt162_block_wtList_Huge_WebbBaseTheme_wt232_block_wtListItem_wtLknComment")
    driver.execute_script("arguments[0].style.border='2px solid red'", divComentario)
    divComentario.click()
    time.sleep(4)    
    divContentComentario = driver.find_elements(By.CSS_SELECTOR, '[data-webbtests="NegociaRFxWeb.RFQ_ParticipantQuotation_Popup_NEW.wblBox25.divContainer2"]')
    span_texts_comentarios = re.findall(r'<span.*?>(.*?)<\/span>', divContentComentario[0].get_attribute('innerHTML') if len(divContentComentario) == 1 else "".join([div.get_attribute('innerHTML') for div in divContentComentario]))
    comentarios = span_texts_comentarios
    print('comentarios:', comentarios)
    # Atualizando a célula
    print(horaVencimento)
    data = [{
                'range': f'BANCO_DE_DADOS!B{indexObjeto}', 
                'values': [[titulo]] 
            },{
                'range': f'BANCO_DE_DADOS!C{indexObjeto}',  
                'values': [[descricaoLongaStr]],
            },{
                'range': f'BANCO_DE_DADOS!D{indexObjeto}',  
                'values': [[divTotalStr]],
            },{
                'range': f'BANCO_DE_DADOS!E{indexObjeto}',  
                'values': [[f'{dataInicio}']]
            },{
                'range': f'BANCO_DE_DADOS!F{indexObjeto}',  
                'values': [[f'{horaInicio}']]
            },{
                'range': f'BANCO_DE_DADOS!G{indexObjeto}',  
                'values': [[f'{dataVencimento}']]
            },{
                'range': f'BANCO_DE_DADOS!H{indexObjeto}',  
                'values': [[f'{horaVencimento}']]
            },{
                'range': f'BANCO_DE_DADOS!I{indexObjeto}',  
                'values': [[local]],
            },{
                'range': f'BANCO_DE_DADOS!J{indexObjeto}',  
                'values': [[";".join(comentarios)]],
            },{
                'range': f'BANCO_DE_DADOS!K{indexObjeto}',  
                'values': [[moedaCotacao]],
            },{
                'range': f'BANCO_DE_DADOS!L{indexObjeto}',  
                'values': [[status]],
            }]
    body = {
        'valueInputOption': 'RAW',  # or 'USER_ENTERED'
        'data': data
    }
    result = sheetsService.spreadsheets().values().batchUpdate(
        spreadsheetId=SPREADSHEET_ID,
        body=body
    ).execute()
    print(f"{result.get('totalUpdatedCells')} cells updated.")
    fimProcesso = time.time()
    tempoTotal = fimProcesso - comecoProcesso
    listaPedidosColetados.append(pedido)
    print(f'Numero: {pedido} - Descricao: {span_texts[len(span_texts)-1]} - tempo: {tempoTotal}')
    driver.switch_to.default_content()
        
        
        
        
        
        
        if fqCode not in df['Pedido ID'].values:
            listAdicionar.append({
                'range': f'BANCO_DE_DADOS!A{sheetsSize+index+1}',
                'values': [[ fqCode ]],
                })
            
    print(listAdicionar)
    time.sleep(60)        
            
    sheetsService.spreadsheets().values().batchUpdate(
        spreadsheetId=SPREADSHEET_ID,
        body={
            'valueInputOption': 'RAW',  # or 'USER_ENTERED'
            'data': [listAdicionar]
        }
    ).execute()
    driver.find_element(by=By.CLASS_NAME, value='ListNavigation_Next').click()
