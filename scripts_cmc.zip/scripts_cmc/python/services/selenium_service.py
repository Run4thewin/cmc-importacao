from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


def click_element(driver, element):
    wait = WebDriverWait(driver, 10)
    element = wait.until(EC.element_to_be_clickable(element))
    driver.execute_script("arguments[0].style.border='2px solid red'", element)
    element.click()