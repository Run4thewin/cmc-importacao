from selenium import webdriver
from selenium.webdriver.common.by import By
import time
from scrap_item_wiautomation import *

driver = webdriver.Chrome()
driver.maximize_window()

# Open the URL
driver.get("https://br.wiautomation.com/brands")  # Replace with the actual URL




# Locate all <div> elements with class 'item_brand'
item_brand_divs = driver.find_elements(By.CLASS_NAME, "item_brand")

# Extract the href attribute from the <a> tag inside each 'item_brand' div
hrefs = [div.find_element(By.TAG_NAME, "a").get_attribute("href") for div in item_brand_divs]

# Print all hrefs
for href in hrefs[::1]:
    driver.get(href)  # Replace with the actual URL
    # Locate all <div> elements with class 'item_brand'
    item_brand_divs_content = driver.find_elements(By.CLASS_NAME, "main_box_content")

    # Extract the href attribute from the <a> tag inside each 'item_brand' div
    hrefs_content = [div.find_element(By.TAG_NAME, "a").get_attribute("href") for div in item_brand_divs_content]
    
    for hrefContext in hrefs_content[::1]:
        driver.get(hrefContext)
        main_product_group = driver.find_elements(By.CLASS_NAME, "main_product_group")
        
        for content_group in main_product_group[::1]:
            more_button_secction = content_group.find_elements(By.CLASS_NAME, "more_products")
            if(len(more_button_secction)>0) :
                more_button_secction_href = [div.find_element(By.TAG_NAME, "a").get_attribute("href") for div in more_button_secction]
                driver.get(more_button_secction_href[0])
                current_page = 0
                total_page = driver.find_elements(By.CLASS_NAME, "total_page")
                if( len(total_page) == 0):
                        item_brand_divs_items = driver.find_elements(By.CLASS_NAME, "wrap_comp_product")
                        # Extract the href attribute from the <a> tag inside each 'item_brand' div
                        hrefs_content_item = [element.find_element(By.TAG_NAME, "a").get_attribute("href") for element in item_brand_divs_items]
                        for href_item in hrefs_content_item:
                            item = scrap_item(driver, href_item)
                            print()
                            print(item)
                
                if( len(total_page) > 0):
                    more_button_secction_href = [div.find_element(By.TAG_NAME, "a").get_attribute("href") for div in more_button_secction]
                    while current_page < total_page[0].get_attribute("innerText"):
                        more_anchor = [element.find_element(By.TAG_NAME, "a").get_attribute("href") for element in more_button_secction]
                        driver.get(more_anchor[0].split('?')[0] + f"?page={current_page}")  # Replace with the actual URL
                        item_brand_divs_items = driver.find_elements(By.CLASS_NAME, "wrap_comp_product")
                        # Extract the href attribute from the <a> tag inside each 'item_brand' div
                        hrefs_content_item = [element.find_element(By.TAG_NAME, "a").get_attribute("href") for element in item_brand_divs_items]
                        for href_item in hrefs_content_item:
                            item = scrap_item(driver, href_item)
                            print()
                            print(item)
                        current_page+=1
                
                
            else:
                item_brand_divs_items = driver.find_elements(By.CLASS_NAME, "wrap_comp_product")
                hrefs_content_item = [element.find_element(By.TAG_NAME, "a").get_attribute("href") for element in item_brand_divs_items]
                for href_item in hrefs_content_item[::1]:
                    item = scrap_item(driver, href_item)
                    print()
                    print(item)

        
# Close the browser
driver.quit()




        