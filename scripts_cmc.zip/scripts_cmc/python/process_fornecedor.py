import pandas as pd
from db import createFabricante

# Replace 'your_file.xlsx' with the path to your file
file_path = 'FORNECEDORES.xlsx'

# Read the Excel file into a DataFrame
df = pd.read_excel(file_path, )

listToAdd = []
# Iterate over each row using itertuples()
for row in df.itertuples(index=True, name='Pandas'):
    if(row.FRABRICANTE not in listToAdd):
        listToAdd.append(row.FRABRICANTE)

for item in listToAdd:
    createFabricante(item)

