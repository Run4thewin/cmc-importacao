import pyodbc
from decimal import Decimal

# Example Python object with attributes
class Orcamento:
    def __init__(self, rfq, titulo_cotacao, descricao_longa, quantidade, data_inicio, hora_inicio, data_fim, hora_fim, endereco, comentario, moeda, status, unidade):
        self.rfq = rfq
        self.titulo_cotacao = titulo_cotacao
        self.descricao_longa = descricao_longa
        self.quantidade = quantidade
        self.data_inicio = data_inicio
        self.hora_inicio = hora_inicio
        self.data_fim = data_fim
        self.hora_fim = hora_fim
        self.endereco = endereco
        self.comentario = comentario
        self.moeda = moeda
        self.status = status
        self.unidade=unidade

class Importacao:
    def __init__(self, rfq, sistema):
        self.rfq = rfq
        self.sistema = sistema
        
class Contact:
    def __init__(self, nome, email, email2=None, email3=None, phone=None, cellular=None):
        self.nome = nome
        self.email = email
        self.email2 = email2
        self.email3 = email3
        self.phone = phone
        self.cellular = cellular

    def __repr__(self):
        return (f"Contato(nome='{self.nome}', email='{self.email}', email2='{self.email2}', "
                f"email3='{self.email3}', phone='{self.phone}', cellular='{self.cellular}')")

    def to_dict(self):
        """Converte o objeto em um dicionário"""
        return {
            'nome': self.nome,
            'email': self.email,
            'email2': self.email2,
            'email3': self.email3,
            'phone': self.phone,
            'cellular': self.cellular
        }

# SQL command with placeholders
sql_command = """
INSERT INTO ORCAMENTO (
    rfq, 
    titulo_cotacao, 
    descricao_longa, 
    quantidade, 
    data_inicio, 
    hora_inicio, 
    data_fim, 
    hora_fim, 
    endereco, 
    comentario,
    moeda,
    status,
    unidade
) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)
"""
def createOrcamento(orcamento: Orcamento):
    # Tuple with the values to insert
    values = (
        orcamento.rfq,
        orcamento.titulo_cotacao,
        orcamento.descricao_longa,
        orcamento.quantidade,
        orcamento.data_inicio,
        orcamento.hora_inicio,
        orcamento.data_fim,
        orcamento.hora_fim,
        orcamento.endereco,
        orcamento.comentario,
        orcamento.moeda,
        orcamento.status,
        orcamento.unidade,
    )

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    cursor.execute(sql_command, values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
def getListImportacao():
    
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    cursor.execute("select rfq, sistema from importacao ORDER BY data_importacao desc")
    listRFQ = []
    myresult = cursor.fetchall()
    for x in myresult:
        rfq, sistema = x
        listRFQ.append({"rfq":rfq, "sistema":sistema})

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listRFQ

def getListOrcamento(where = ""):
    
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    query = f'select rfq, titulo_cotacao, descricao_longa, quantidade, data_inicio, hora_inicio, data_fim, hora_fim, endereco, comentario, moeda, unidade, status from orcamento {where} order by rfq, DATA_IMPORTACAO'
    print(query)
    cursor.execute(query)
    listRFQ = []
    myresult = cursor.fetchall()
    for x in myresult:
        rfq, titulo_cotacao, descricao_longa, quantidade, data_inicio, hora_inicio, data_fim, hora_fim, endereco, comentario, moeda, unidade, status = x
        listRFQ.append({
            "rfq": rfq,
            "sistema": "nimbi",  # Valor fixo, conforme exemplo
            "titulo_cotacao": titulo_cotacao,
            "descricao_longa": descricao_longa,
            "quantidade": float(quantidade),
            "data_inicio": data_inicio.strftime("%d/%m/%Y"),
            "hora_inicio": hora_inicio,
            "data_fim": data_fim.strftime("%d/%m/%Y"),
            "hora_fim": hora_fim,
            "endereco": endereco,
            "comentario": comentario,
            "moeda": moeda,
            "unidade": unidade,
            "status": status
        })

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listRFQ

def get_contacts():
    
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    cursor.execute("select id, email from Contact")
    listRFQ = []
    myresult = cursor.fetchall()
    for x in myresult:
        id, name_contact = x
        listRFQ.append({"id":id, "email":name_contact})

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listRFQ


def createImportacao(importacao: Importacao):
    # Tuple with the values to insert
    values = (
        importacao.rfq,
        importacao.sistema,
    )

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    cursor.execute("INSERT INTO IMPORTACAO (rfq, sistema) VALUES (?,?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()

def createFabricante(manufacture):
    # Tuple with the values to insert
    values = (manufacture)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    print("INSERT INTO MANUFACTURE (NAME_MANUFACTURE) VALUES (?)", values)
    # Execute the SQL command with values
    cursor.execute("INSERT INTO MANUFACTURE (NAME_MANUFACTURE) VALUES (?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()

def createSupplier(manufacture):
    # Tuple with the values to insert
    values = (manufacture)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    # Execute the SQL command with values
    cursor.execute("INSERT INTO supplier (name_supplier) VALUES (?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()


def createContact(manufacture: Contact):
    # Tuple with the values to insert
    values = (
        manufacture.nome,
        manufacture.email, 
        manufacture.email2, 
        manufacture.email3, 
        manufacture.phone, 
        manufacture.cellular)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )
    print(values)
    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    # Execute the SQL command with values
    cursor.execute("INSERT INTO Contact (name_contact, email, email2, email3, phone, cellular) VALUES (?, ?, ?, ?, ?, ?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()


def create_manufacture_suplier(manufactor, supplier):
    # Tuple with the values to insert
    values = (manufactor,supplier)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )
    print(values)
    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    # Execute the SQL command with values
    cursor.execute("INSERT INTO manufacture_supplier VALUES (?, ?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()


def create_contact_supplier(contact, supplier):
    # Tuple with the values to insert
    values = (contact,supplier)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )
    print(values)
    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    # Execute the SQL command with values
    cursor.execute("INSERT INTO supplier_contact VALUES (?, ?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()





def get_suppliers(where = ""):
    
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    query = f'select id, name_supplier from supplier {where}'
    
    cursor.execute(query)
    listSupplier = []
    myresult = cursor.fetchall()
    for x in myresult:
        id, name_supplier = x
        listSupplier.append({ "id": id, "name_supplier": name_supplier })

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listSupplier



def get_manufactors(where = ""):
    
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    query = f'select id, name_manufacture from manufacture {where}'

    cursor.execute(query)
    listManufacture = []
    myresult = cursor.fetchall()
    for x in myresult:
        id, name_manufacture = x
        listManufacture.append({ "id": id, "name_manufacture": name_manufacture })

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listManufacture


def create_email(to, html):
    # Tuple with the values to insert
    values = (to, html)

    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )
    print(values)
    # Create a cursor object to interact with the database
    cursor = conn.cursor()
    # Execute the SQL command with values
    cursor.execute("INSERT INTO automate_email(email_to, html) VALUES (?, ?)", values)

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
def get_list_email(where = ""):
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    query = f'select id, email_to, html, status_email, created_at, updated_at from automate_email {where}'

    cursor.execute(query)
    listEmail = []
    myresult = cursor.fetchall()
    for x in myresult:
        id, email_to, html, status_email, created_at, updated_at = x
        listEmail.append({ "id": id, "email_to": email_to, "html": html, "status_email": status_email,  "created_at":created_at, "updated_at": updated_at })

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listEmail

def get_list_contact_by_manufacture(idManufacture):
    # Establish a database connection (example using psycopg2 for PostgreSQL)
    conn = pyodbc.connect(
        'DRIVER={ODBC Driver 17 for SQL Server};'
        'SERVER=ONCD-N002\SQLEXPRESS;'
        'DATABASE=cmc;'
        'UID=CMC_API;'
        'PWD=#df4f#$%3km4kf4çmfk4m;'
        'PORT=1433;'
    )

    # Create a cursor object to interact with the database
    cursor = conn.cursor()

    # Execute the SQL command with values
    query = f"""
            select cont.name_contact, cont.email, cont.email2, cont.email3
        from manufacture_supplier man_sup
            inner join manufacture manu 
                on man_sup.id_manufacture = manu.id
            inner join supplier supp
                on man_sup.id_supplier = supp.id
            inner join supplier_contact supp_cont
                on supp_cont.id_supplier = supp.id
            inner join contact cont
                on supp_cont.id_contact = cont.id
        where manu.id = {idManufacture}"""

    cursor.execute(query)
    listEmail = []
    myresult = cursor.fetchall()
    for x in myresult:
        name_contact, email, email2, email3 = x
        listEmail.append({ "name_contact": name_contact, "email": email, "email2": email2, "email3": email3})

    # Commit the transaction
    conn.commit()

    # Close the cursor and connection
    cursor.close()
    conn.close()
    
    return listEmail
