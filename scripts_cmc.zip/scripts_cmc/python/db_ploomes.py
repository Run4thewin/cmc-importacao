from db import getListOrcamento
from ploomes import criar_orcamento, OrcamentoPloomes
import time

listaOrcamento = getListOrcamento() 
listaOrcmentosObj = []
for orcamentoDb in listaOrcamento[:1]:
    listaOrcmentosObj.append(OrcamentoPloomes(
            rfq=orcamentoDb['rfq'],
            title=orcamentoDb['titulo_cotacao'],
            stageId=110012824,
            descricao_longa=orcamentoDb['descricao_longa'],
            quantidade=orcamentoDb['quantidade'],
            data_fim=orcamentoDb['data_fim'],
            hora_fim=orcamentoDb['hora_fim'],
            endereco=orcamentoDb['endereco'],
            comentario=orcamentoDb['comentario'],
            moeda=orcamentoDb['moeda'],
            unidade=orcamentoDb['unidade'],
        ).to_ploomes())

[{criar_orcamento(listaPloomes), time.sleep(2)} for listaPloomes in listaOrcmentosObj]
