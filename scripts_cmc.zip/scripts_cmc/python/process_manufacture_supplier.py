from db import get_suppliers, get_manufactors, create_manufacture_suplier
from planilha_fornecedor import get_df
import pandas as pd

listaManufac = get_manufactors()

listaSupplier = get_suppliers()

dados_planilha = get_df()

df = pd.DataFrame(dados_planilha)

listAddDB = []

for man in listaManufac:
    manufactoryName = man['name_manufacture']
    
    df_selected_names = df[df['FRABRICANTE'].isin([manufactoryName])]
    for item in df_selected_names[['FRABRICANTE', 'REPRESENTANTE']].values.tolist():

        fabricante, representante = item

        dfManu = pd.DataFrame(listaManufac)
        manufac = dfManu[dfManu['name_manufacture'].isin([fabricante])]['id'].tolist()
        
        dfSupp = pd.DataFrame(listaSupplier)
        supplierList = dfSupp[dfSupp['name_supplier'].isin([representante])]['id'].tolist()
        
        if(len(supplierList)>0):
            listAddDB.append({"manufactor":manufac[0],"supplier":supplierList[0]})

[create_manufacture_suplier(item['manufactor'], item['supplier']) for item in listAddDB]

